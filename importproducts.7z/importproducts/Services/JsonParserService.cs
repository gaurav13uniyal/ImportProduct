﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ImportProduct.Models;
using Newtonsoft.Json;


namespace ImportProduct.Services
{
    public class JsonParserService<T>:BaseParserService<T> where T : IParserModel, new()
    {
        
        public async override Task<T> ParseContent(string path)
        {
           T parserModel = JsonConvert.DeserializeObject<T>(File.ReadAllText(path));
            return parserModel;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ImportProduct.Models
{
    public class SoftwareAdviceParserModel:IParserModel
    {
        public List<Product> products { get; set; }
    }
}

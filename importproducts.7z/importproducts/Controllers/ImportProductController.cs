using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using ImportProduct.Models;
using ImportProduct.Services;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace ImportProductApi.Controllers
{
    [Route("api/[controller]")] 
    [ApiController]
    public class ImportProductController : Controller
    {
      
        private readonly IParserService<IParserModel> softwareAdvice;
        private readonly IHostingEnvironment _hostingEnvironment;
        private Task<IParserModel> _softwareAdviceModel;
        public ImportProductController(IParserService<IParserModel> _softwareAdvice, IHostingEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;
            var rootPath = _hostingEnvironment.ContentRootPath; //get the root path

            var fullPath = Path.Combine(rootPath, "feed-products/softwareadvice.json");
            softwareAdvice = _softwareAdvice;

            _softwareAdviceModel = softwareAdvice.ParseContent(fullPath);
            
            }

        [HttpGet]
        public async Task<IParserModel> GetProducts()
        {
            return await _softwareAdviceModel;
        }
    }    
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ImportProduct.Models;

namespace ImportProduct.Services
{
    public interface IParserService<T> where T : IParserModel
    {
        Task<T> ParseContent(string path);
    }
}

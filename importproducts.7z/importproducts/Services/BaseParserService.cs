﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ImportProduct.Models;

namespace ImportProduct.Services
{
    public abstract class BaseParserService<T> : IParserService<T> where T : IParserModel, new()
    {
        public async virtual Task<T> ParseContent(string path)
        {
            return await Task.FromResult(new T());
        }
    }
}
